############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 제한 내장 함수: map, max, sum
# 기본 점수 (9점): 제한 내장 함수를 사용한 해결
# 가산점(+3점): 제한 내장 함수 없이 직접 구현 (총 12점)

def sum_row_maximums(matrix):
    # 여기에 코드를 작성하여 함수를 완성합니다.
    # maximum = [0] * len(matrix)
    # for i in range(len(matrix))
    maximum_sum = 0
    for row in matrix:
        maximum = row[0]
        for collum in row:
            if collum >= maximum:
                maximum = collum
        maximum_sum += maximum
    return maximum_sum

# 추가 테스트를 위한 코드 작성 가능
# 예) print(함수명(인자))

#####################################################
# 아래 코드를 삭제하는 경우 
# 모든 책임은 삭제한 본인에게 있습니다.
############## 테스트 코드 삭제 금지 #################
print(sum_row_maximums([[1, 2, 3], [4, 5, 6], [7, 8, 9]])) # 18
print(sum_row_maximums([[-1, -2, -3], [-10, -5, -1], [-100, -200, -300]])) # -102
print(sum_row_maximums([[5]])) # 5
#####################################################
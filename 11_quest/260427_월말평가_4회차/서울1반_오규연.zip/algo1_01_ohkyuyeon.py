# import sys
# sys.stdin = open("algo1_sample_in.txt")


T = int(input())


for tc in range(1, T + 1):
    V, E = map(int, input().split())
    bridges = list(map(int, input().split()))
    """
    graph = [[] for _ in range(V + 1)]

    for i in range(0, E * 2, 2):
        a, b = bridge[i], bridge[i + 1]
        graph[a].append(b)
        graph[b].append(a)
    """
    # 간선 하나는 두 행성 각각의 우주항로 하나를 의미한다.
    # 즉 간선 정보에서 어떠한 행성 번호의 개수는 그 행성이 가진 항로 수와 동일하다.
    # bridge_cnt: 인덱스의 해당하는 행성이 가진 항로 수를 저장하는 변수
    # 행성 번호는 1번부터 시작하므로 0번 인덱스를 비워두고 V+1번 인덱스까지 만들며,
    # 0으로 초기화한다.
    bridge_cnt = [0] * (V + 1)

    # 1번부터 V번까지 순회
    for i in range(1, V + 1):
        # 간선 정보 bridges에 포함된 각 행성 번호의 개수를 세고,
        # bridge_cnt에 저장한다.
        bridge_cnt[i] = bridges.count(i)

    # bridge_cnt의 최댓값을 구하여, 가장 많이 연결된 행성의 연결 개수를 출력한다.
    print(f"#{tc} {max(bridge_cnt)}")


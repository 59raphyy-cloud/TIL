# import sys
# sys.stdin = open("algo2_sample_in.txt")
from heapq import heappush, heappop


T = int(input())


# 시작 행성에서 각 행성에 도달하기 위한 최소 연료소요량을 구하는 함수
def dijkstra(start):
    pq = [(0, start)]
    fuel = [0] + [INF] * V  # 연료소요량 아주 큰 값으로 초기화
    fuel[start] = 0  # 시작 행성의 연료소요량 0으로 재설정

    while pq:
        cur_fuel, cur_node = heappop(pq)

        # 현재 필요한 연료량이 기존에 저장된 값보다 크다면 다음 반복 진행
        if cur_fuel > fuel[cur_node]:
            continue

        for next_fuel, next_node in graph[cur_node]:
            # 다음 행성으로 가기 위한 연료소요량 누적
            new_fuel = cur_fuel + next_fuel

            # 기존에 저장된 값보다 새로 누적된 값이 작다면
            if new_fuel < fuel[next_node]:
                fuel[next_node] = new_fuel  # 필요한 최소 연료소요량 갱신
                heappush(pq, (new_fuel, next_node))  # push 후 다음 반복 진행

    return fuel  # 각 행성에 도달하기 위한 최소 연료소요량 반환


for tc in range(1, T + 1):
    V, E = map(int, input().split())
    graph = [[] for _ in range(V + 1)]  # 인접리스트 생성

    INF = int(10e10)  # 최댓값 설정

    for _ in range(E):
        a, b, w = map(int, input().split())

        # 양방향이므로 각 행성에 연료소요량과 상대 행성을 튜플로 저장
        graph[a].append((w, b))
        graph[b].append((w, a))

    # 함수 호출하여 1번에서 각 행성에 도달하기 위한 최소 연료소요량 리스트 반환받음
    fuel_need = dijkstra(1)

    if fuel_need[V] == INF:    # V번 행성에 도달하기 위한 연료소요량이 갱신되지 않았다면
        result = -1            # 도달 불가하므로 -1 할당
    else:
        result = fuel_need[V]  # 갱신되었다면 결과에 최소 연료소요량 할당

    print(f"#{tc} {result}")
